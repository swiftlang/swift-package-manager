import Foo

foo()
