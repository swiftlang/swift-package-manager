struct dep {
    var text = "Hello, World!"
}
