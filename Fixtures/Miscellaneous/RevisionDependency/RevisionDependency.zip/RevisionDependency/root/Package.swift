// swift-tools-version:5.0

import PackageDescription

let package = Package(
    name: "root",
    dependencies: [
        .package(url: "../dep", .revision("1c95e9a18e6295492a")),
    ],
    targets: [
        .target(
            name: "root",
            dependencies: ["dep"]),
    ]
)
