struct root {
    var text = "Hello, World!"
}
